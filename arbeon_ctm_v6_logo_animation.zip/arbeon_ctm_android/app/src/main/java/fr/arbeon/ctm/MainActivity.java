package fr.arbeon.ctm;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private static final int CREATE_BACKUP = 4101;
  private static final int OPEN_BACKUP = 4102;
  private WebView web;
  private String pendingBackup = null;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(7,21,15));
    getWindow().setNavigationBarColor(Color.rgb(7,21,15));
    web = new WebView(this);
    web.setBackgroundColor(Color.rgb(7,21,15));
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setBuiltInZoomControls(false);
    web.addJavascriptInterface(new BackupBridge(), "ArbeonBackup");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  private class BackupBridge {
    @JavascriptInterface public void save(String json) {
      runOnUiThread(() -> {
        pendingBackup = json;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "arbeon-ctm-sauvegarde.json");
        startActivityForResult(intent, CREATE_BACKUP);
      });
    }
    @JavascriptInterface public void restore() {
      runOnUiThread(() -> {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, OPEN_BACKUP);
      });
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent result) {
    super.onActivityResult(requestCode, resultCode, result);
    if (resultCode != RESULT_OK || result == null || result.getData() == null) { pendingBackup = null; return; }
    Uri uri = result.getData();
    try {
      if (requestCode == CREATE_BACKUP && pendingBackup != null) {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
          if (out == null) throw new Exception("Impossible d'ouvrir le fichier");
          out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
          out.flush();
        }
        pendingBackup = null;
        web.evaluateJavascript("backupSaved()", null);
      } else if (requestCode == OPEN_BACKUP) {
        String json;
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
          if (in == null) throw new Exception("Impossible de lire le fichier");
          byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
          json = out.toString("UTF-8");
        }
        String encoded = android.util.Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
        web.evaluateJavascript("receiveBackup(atob('" + encoded + "'))", null);
      }
    } catch (Exception e) {
      pendingBackup = null;
      web.evaluateJavascript("backupError('Erreur lors de l’accès au fichier. Vérifie l’espace de stockage et réessaie.')", null);
    }
  }

  @Override public void onBackPressed() { super.onBackPressed(); }
}
