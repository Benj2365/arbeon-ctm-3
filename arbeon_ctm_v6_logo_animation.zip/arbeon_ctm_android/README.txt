ARBEON CTM — version de préparation commerciale 1.1

- Fonctionnement hors ligne, sans compte obligatoire.
- Sauvegarde JSON via le sélecteur de documents Android (choisir Google Drive ou un autre emplacement proposé par Android).
- Restauration depuis un fichier JSON avec validation et confirmation avant remplacement des données.
- Cible Android 16 / API 36 pour préparer la conformité de la soumission Google Play.
- Workflow GitHub Actions : produit un APK de test et un bundle AAB de release.

IMPORTANT AVANT PUBLICATION GOOGLE PLAY
Cette version est une base technique, pas une publication prête à être mise en vente. Le bundle release doit être signé avec une clé de publication. Pour vendre 5 €/an, il faut intégrer et tester Google Play Billing, créer le produit d'abonnement dans Play Console et gérer les achats/restaurations/expiration. Il faut également préparer une politique de confidentialité accessible par URL, compléter les déclarations Play Console (dont Sécurité des données), les éléments de fiche Play et effectuer les tests requis. La compilation seule ne garantit pas l'approbation par Google.

Les données sont stockées localement dans l'application. Il est conseillé de créer une sauvegarde avant toute mise à jour importante et de tester la restauration avant utilisation réelle.
